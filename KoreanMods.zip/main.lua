mods["ReturnsAPI-ReturnsAPI"].auto{
    namespace = "KoreanMods",
    mp = true
}
