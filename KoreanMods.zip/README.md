# KoreanMods
몇 가지 텍스트들을 개선하고 일부 수치 표기 오류를 수정합니다.
추가로 일부 모드 번역을 포함합니다.

## 모드 번역
### Starstorm Returns (WIP)
- 현재 번역 중입니다.